<?php

if(isset($_POST['upload'])) {

    $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
    $upload_folder = DVWA_WEB_PAGE_TO_ROOT . "hackable/uploads/";

    // Check if the file extension is allowed
    $file_extension = strtolower(pathinfo($_FILES['uploaded']['name'], PATHINFO_EXTENSION));
    if(!in_array($file_extension, $allowed_extensions)) {
        echo "<pre>Invalid file extension. Allowed extensions are " . implode(',', $allowed_extensions) . "</pre>";
        exit;
    }

    // Check if the file was uploaded successfully
    if($_FILES['uploaded']['error'] !== UPLOAD_ERR_OK) {
        echo "<pre>File upload failed with error code: " . $_FILES['uploaded']['error'] . "</pre>";
        exit;
    }

    // Check if the upload folder is writable
    if(!is_writable($upload_folder)) {
        echo "<pre>Upload folder is not writable by the server.</pre>";
        exit;
    }

    // Generate a unique filename to avoid overwriting existing files
    $new_filename = uniqid() . '.' . $file_extension;
    $target_path = $upload_folder . $new_filename;

    // Move the uploaded file to the upload folder
    if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target_path)) {
        echo "<pre>File uploaded successfully to: " . $target_path . "</pre>";
    }
    else {
        echo "<pre>File upload failed. Please try again later.</pre>";
    }
}

?>
