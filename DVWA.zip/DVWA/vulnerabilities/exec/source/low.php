<?php

if (isset($_POST['Submit'])) {
    // Get input and sanitize it
    $target = filter_var($_POST['ip'], FILTER_SANITIZE_STRING);

    // Determine OS and execute the ping command.
    if (stristr(php_uname('s'), 'Windows NT')) {
        // Windows
        $cmd = 'ping ' . escapeshellcmd($target);
    } else {
        // *nix
        $cmd = 'ping -c 4 ' . escapeshellcmd($target);
    }

    // Execute the command using the shell_exec function
    $output = shell_exec($cmd);

    // Feedback for the end user
    echo "<pre>{$output}</pre>";
}

?>
