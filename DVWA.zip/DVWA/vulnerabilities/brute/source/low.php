<?php
// Start the session
session_start();

// Check if the login form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['password'])) {
    // Get the username and password from the POST request
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Connect to the database
    $db_host = 'localhost';
    $db_name = 'database_name';
    $db_user = 'database_user';
    $db_pass = 'database_password';

    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare the SQL statement
    $stmt = mysqli_prepare($conn, "SELECT id, username, password, avatar FROM users WHERE username = ?");

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "s", $username);

    // Execute the query
    mysqli_stmt_execute($stmt);

    // Get the results
    mysqli_stmt_bind_result($stmt, $id, $db_username, $db_password, $avatar);
    mysqli_stmt_fetch($stmt);

    // Check if the password matches
    if (password_verify($password, $db_password)) {
        // Set session variables
        $_SESSION['user_id'] = $id;
        $_SESSION['username'] = $db_username;
        $_SESSION['avatar'] = $avatar;

        // Redirect to the protected area
        header("Location: protected.php");
        exit();
    } else {
        // Login failed
        $_SESSION['login_error'] = "Invalid username or password";
        header("Location: login.php");
        exit();
    }
} else {
    // Display the login form
    include 'login_form.php';
}
