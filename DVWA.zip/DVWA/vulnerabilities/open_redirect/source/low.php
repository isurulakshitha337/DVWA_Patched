<?php

$allowed_urls = array("https://example.com/", "https://www.example.com/");

if (array_key_exists ("redirect", $_GET) && $_GET['redirect'] != "") {
    $redirect_url = $_GET['redirect'];
    // Check if the URL is in the whitelist
    if (in_array($redirect_url, $allowed_urls)) {
        header ("location: " . $redirect_url);
        exit;
    }
}

http_response_code (500);
?>
<p>Invalid or missing redirect target.</p>
<?php
exit;
?>
